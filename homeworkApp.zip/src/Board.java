import java.util.LinkedList;
import java.util.Scanner;

public class Board {
	static LinkedList<Contents> list = new LinkedList<>();
	static int choice;

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		do {
			choice = userChoice();

			switch (choice) {
				case 1:
					list.add(register());
					break;
	
				case 2:
					try {
						showBrief();
					} catch (WrongNumException e) {
						System.out.println(e.getMessage());
					}
					break;
	
				case 3:
					showFull();
					break;
	
				case 4:
					try {
						delete();
					} catch (WrongNumException e) {					
						System.out.println(e.getMessage());
					}
					break;
	
				case 5:
					try {
						edit();
					} catch (WrongNumException e) {					
						System.out.println(e.getMessage());
					}
					break;
				}
			
		} while (choice != 6);

		scan.close();
		
	}
	
	

	public static int userChoice() {
		Scanner scan = new Scanner(System.in);
		System.out.println(" ");
		System.out.println("###### 게시판 프로그램 ######");
		System.out.println("1. 게시글 등록");
		System.out.println("2. 게시글 목록 조회");
		System.out.println("3. 게시글 상세 조회");
		System.out.println("4. 게시글 삭제");
		System.out.println("5. 게시글 수정");
		System.out.println("6. 종료");
		System.out.println("원하는 항목을 선택하세요.");
		System.out.println(" ");
		int choice = scan.nextInt();

		return choice;
	}

	public static Contents register() {
		Scanner scan = new Scanner(System.in);
		System.out.println(" ");
		System.out.println("\n게시글 등록");
		System.out.println("- 제목     : ");
		String title = scan.nextLine();
		System.out.println("- 작성자   :");
		String writer = scan.nextLine();
		System.out.println("- 내용     :");
		String content = scan.nextLine();
		System.out.println("- 비밀번호 :");
		System.out.println(" ");
		String pwd = scan.nextLine();

		Contents word = new Contents(writer, title, content, pwd);
		return word;

	}

	public static void showBrief() {
		System.out.println(" ");
		System.out.println("게시글 목록 조회");
		System.out.println("번호     작성자     제목");
		System.out.println("=========================================================");

		for (Contents temp : list) {
			System.out.println(temp.toStringbrief());
			System.out.println(" ");
		}

	}

	public static void showFull() throws WrongNumException {
		System.out.println("게시글 상세 조회");
		
		Scanner scan = new Scanner(System.in);

		System.out.println("- 번호     : ");
		int no = Integer.parseInt(scan.nextLine());

		Contents con = findContentsByNo(no);

		System.out.println("번호  작성자  제목  내용  비밀번호");
		System.out.println("=========================================================");
		System.out.println(con.toString());
			
	}

	public static Contents findContentsByNo(int no) throws WrongNumException {
		for (int i = 0; i < list.size(); i++) {
			Contents content = list.get(i);
			if (no == content.getNo()) {
				return content;
			}
		}
		throw new WrongNumException();
	}
	

	public static void delete() throws WrongNumException {
		System.out.println("\n게시글 삭제");
		
		Scanner scan = new Scanner(System.in);		

		System.out.println("- 번호     : ");
		int no = Integer.parseInt(scan.nextLine());

		Contents contents = findContentsByNo(no);

		System.out.println("- 비밀번호 :");
		String pwd = scan.nextLine();

		if (pwd.equals(contents.getPwd())) {
			list.remove(contents);
			System.out.printf("%d번 게시물이 삭제되었습니다.\n", contents.getNo());
		} else {
			System.out.println("비밀빈호가 일치하지 않습니다.\n");
		}

	}
	

	public static void edit() throws WrongNumException {
		Scanner scan = new Scanner(System.in);

		System.out.println("- 번호     : ");
		int no = Integer.parseInt(scan.nextLine());

		Contents con = findContentsByNo(no);

		System.out.println("- 제목     : ");
		String title = scan.nextLine();

		System.out.println("- 작성자   :");
		String writer = scan.nextLine();

		System.out.println("- 내용     :");
		String content = scan.nextLine();

		System.out.println("- 비밀번호 :");
		String pwd = scan.nextLine();

		if (pwd.equals(con.getPwd())) {
			con.setTitle(title);
			con.setWriter(writer);
			con.setContent(content);
			System.out.println("\n게시글이 수정되었습니다\n");

		} else {
			System.out.println("비밀번호가 일치하지 않습니다.\n");
		}

	}

}
