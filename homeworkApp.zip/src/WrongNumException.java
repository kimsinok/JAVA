public class WrongNumException extends RuntimeException{
	
	
    public WrongNumException(String Message) {
        super(Message);
    }

    public WrongNumException() {
        super("해당 게시물을 찾을 수 없습니다.");
    }

   
}
