
public enum Menu {
	CREATE, LIST, RETRIEVE, REMOVE, MODIFY, EXIT;
}
