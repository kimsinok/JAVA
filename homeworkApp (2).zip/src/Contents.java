public class Contents {

    public static int num;

    int no;
    String writer;
    String title;
    String content;
    String pwd;

    static {
        num = 0;
    }


    public Contents(String writer, String title, String content, String pwd) {
        this.no = ++num;
        this.writer = writer;
        this.title = title;
        this.content = content;
        this.pwd = pwd;
    }

    public Contents() {
        num++;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        writer = writer;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    @Override
    public String toString() {
        return no +"   "+ writer +"   "+ title +"   "+ content +"   "+ pwd;
    }

    public String toStringbrief() {
        return no +"     "+ writer +"     "+ title;
    }


}
